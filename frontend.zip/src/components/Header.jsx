import React from 'react';
import './FrontStyle.css';

    function Header() {
      return(
        <>
        <div className='header'>
        
        <ul>  
         <l1></l1>         
            <li><p><img src="/img/reedlogo.png" className="App-logo" alt="logo" width={300} /> </p> </li>      
            <h1></h1>
        <li><h1>Redeemer's University</h1></li>
        </ul>
        </div>
        
      
        </>
       );
    }

export default Header;
