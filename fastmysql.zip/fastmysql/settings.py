from pydantic import BaseModel

# Security settings
SECRET_KEY = "3885cac067064bf3098f62854c211e68e78fcdc0abacf5935a39a509cec31964"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30